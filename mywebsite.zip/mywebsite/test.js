<html>
<body>
<script>  
// It is single line comment  
document.write("hello javascript");  
</script> 
</body>
</html>

 