<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: log-in.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>About Us </title>
        <link rel="stylesheet" href="aboutus.css">
        <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
        <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#" style="margin-left: 10px;">Custom<br>Cuisine</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" style="margin-left: 10px;">
        <li class="active"><a href="web.php">Home</a></li>

        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="addcart.php"><button type="button" class="btn btn-default btn-sm" style="margin-top: -5px;">
          <span class="glyphicon glyphicon-shopping-cart"></span>Food Cart
        </button></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo htmlspecialchars($_SESSION["username"]); ?>
        </a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Log-out</a></li>
      </ul>
    </div>
  </div>
</nav>
        <section>
            <div class = "image">
              <center> <img src="asserts/images/logo.png"height='270'></center>
               
            </div>
           
               

            <div class = "content">
                <h2>About Us</h2>
                <span><!-- line here --></span>
                <p>Cloud kichen utilizes a commercial kitchen for 
                the purpose of preparing food for delivery or
                takeout only, with no-dine in customers.
                It minimizes rentals,needs less capital expenditure
                to set up and requires less manpower and overhead cost to run.
                we are also customizing the foods based on customer requirements
                for that we are providing separate suggestion box in cart
                page.Customers can place their order through our custom cuisine website.</p>
                <ul class = "links">
                    <li><a href = "#">Order</a></li>
                    <div class = "vertical-line"></div>
                    <li><a href = "#">Eat</a></li>
                    <div class = "vertical-line"></div>
                    <li><a href = "#">Enjoy</a></li>
                </ul>
                <ul class = "icons">
                    <li>
                        <i class = "fa fa-twitter"></i>
                    </li>
                    <li>
                        <i class = "fa fa-facebook"></i>
                    </li>
                    <li>
                        <i class = "fa fa-instagram"></i>
                    </li>
                    
                </ul>
            </div>
        </section><br><br>


       
        <div class="credit">Made with <span style="color:red">❤</span> by <a href="#">Custom Cuisine</a></div>
<br><br>


  <div class="footer">
                         <div class="row"style="color:#f5f6fa ;background:#101010;">
                              <div class="col-md-3 text-center">
                                  <h4><span class="glyphicon glyphicon-map-marker"></span>&nbsp;Location</h4>
                                  A17 & 18,guindy industrial estate<br>
                                  sidco industrial estate,guindy<br>
                                  chennai,tamil nadu 600032
                              </div>
                              <div class="col-md-3 text-center">
                                  <h4><span class="glyphicon glyphicon-earphone"></span>&nbsp;Contact</h4>
                                  044 4204 0045
                                
                              </div>
                              <div class="col-md-3 text-center">
                                   <h4><span class="glyphicon glyphicon-envelope"></span>&nbsp;Email</h4>
                                   sales@perficient.com
                              </div>
                              <div class="col-md-3 text-center">
                                   <h4><span class="glyphicon glyphicon-paperclip"></span>&nbsp;Website</h4>
                                   https://www.perficient.com
                              </div>
               </div>
    </body>
</html>
