
<?php
// Initialize the session
session_start();
    $_SESSION['A'] = "Chicken Biryani";
    $_SESSION['B'] = "Non-veg Meals";
    $_SESSION['C'] = "Chicken Fry";
    $_SESSION['D'] = "Spl Combo";
    $_SESSION['E'] = "Veg Meals";
    $_SESSION['F'] = "Combo Tiffins";
    $_SESSION['a'] = 110;
    $_SESSION['b'] = 70;
    $_SESSION['c'] = 99;
    $_SESSION['d'] = 210;
    $_SESSION['e'] = 70;
    $_SESSION['f'] = 110;
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: log-in.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Custom Cuisine</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="script.js"></script>
    <style>
           body{
      background-color: #eee;
      line-height: 1;
      background-image: url("asserts/images/background.png");
      background-size: cover;
    }
   .navbar-brand{
    margin: -10px;
    margin-left: 10px;
    font-family: cursive;
    }
     .btn{
    
    border: 1px solid #8e44ad;
    color: #8e44ad;
    float: right;
    position: absolute;
    display: inline-block;
    position: static;
    border-radius: 17px;
  }
  .row{
    margin-right: 0px;
    margin-left: 0px;
  }
  .card{
    position: static;
    border: 2px solid #8e44ad;
    box-shadow: 10px 10px 10px #eee;
    margin: 15px;
    height: 300px;
  }
  .quantity .input-text.qty {
 width: 35px;
 height: 18px;
 padding: 0 5px;
 text-align: center;
 background-color: transparent;
 border: 1px solid #8e44ad;
}

.quantity.buttons_added {
 text-align: left;
 position: relative;
 white-space: nowrap;
 vertical-align: top; }

.quantity.buttons_added input {
 display: inline-block;
 margin: 0;
 vertical-align: top;
 box-shadow: none;
}

.quantity.buttons_added .minus,
.quantity.buttons_added .plus {
 border-radius: 5px;
 height: 18px; 
 border: 1px solid #8e44ad;
 cursor:pointer;}
 ul{
 margin-left: 10px;
 }
 #slide img{
 width: 100%;
 height: 296px;
 }
    </style>
 
</head>
<body>
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Custom<br>Cuisine</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="web.php">Home</a></li>

        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="addcart.php"><button type="button" class="btn btn-default btn-sm" style="margin-top: -5px;float: left;">
          <img src="shopping-cart.png" height="15px" width="15px"> Food Cart
        </button></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo htmlspecialchars($_SESSION["username"]); ?>
        </a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Log-out</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="image"><marquee width="100%" behavior="alternate"><img src="asserts/images/logo.png"height='200'></marquee></div>
<div class="container-fluid"> 
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" id="slide" style="background-color:#cfbcbc;">
      <div class="item active">
        <br><br><br>
   <div class="row">
       <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s7.png"><br>
          
         </div>
      </div>
      <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s8.jpg"><br>
         
         </div>
      </div>
      <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s9.png"><br>
        
         </div>
      </div>
      </div>
<br><br><br>
    </div>

      <div class="item" id="slide">
        <br><br><br>
        <div class="row">
       <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s4.png">
            
         </div>
      </div>
      <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s5.png">
          
         </div>
      </div>
      <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s6.jpg">
            
         </div>
      </div>
      </div><br><br><br>
    </div>

      <div class="item " id="slide">
        <br><br><br>

          <div class="row">
       <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s1.png">
            
         </div>
      </div>
      <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s2.png">
         
         </div>
      </div>
      <div class="col-md-4">
         <div class="card">
            <img src="asserts/images/s3.png">
           
         </div>
      </div>
      </div>
     


     <br><br><br>
    </div>

      
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
    
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>

    </a>
  </div>
</div>




<br><br>


<div class="container-fluid">
  <div class="col-md-12">
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <img src="asserts/images/img1.jpg" width="100%" height="200">
             <div class="row" style="margin-top: 10px;">
          <div class="col-md-6">
               <p style="color:#8e44ad;"><b>&nbsp;&nbsp;<?php echo $_SESSION['A'] ?></b></p> </div>
              <div class="col-md-6">
                 <div class="quantity buttons_added" style="float: right;">
  <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity_1" value="1" title="Qty" class="input-text qty text form-control" size="4" pattern="" inputmode=""><input type="button" value="+" class="plus">
            </div></div></div>

            <div class="row">
               <div class="col-md-8">
                <div style="margin-top:-10px">
                &nbsp;&nbsp;<i class="glyphicon glyphicon-star" style="color: #e39738">5</i><p><br></p>
                <p><b>&nbsp;&nbsp;₹<?php echo $_SESSION['a'] ?></b></p>
               </div></div>

               <div class="col-md-4">
                  <br>
              <center><input type="submit" class="btn" name="submit" value="Add"></center>
               </div>
            </div>
        </div>
      </div>

            <div class="col-md-4">
        <div class="card">
          <img src="asserts/images/img2.jpg" width="100%" height="200">
             <div class="row" style="margin-top: 10px;">
          <div class="col-md-6">
               <p style="color:#8e44ad;"><b>&nbsp;&nbsp;<?php echo $_SESSION['B'] ?></b></p> </div>
              <div class="col-md-6">
                 <div class="quantity buttons_added" style="float: right;">
  <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity_1" value="1" title="Qty" class="input-text qty text form-control" size="4" pattern="" inputmode=""><input type="button" value="+" class="plus">
            </div></div></div>

            <div class="row">
               <div class="col-md-8">
                <div style="margin-top:-10px">
                &nbsp;&nbsp;<i class="glyphicon glyphicon-star" style="color: #e39738">5</i><p><br></p>
                <p><b>&nbsp;&nbsp;₹<?php echo $_SESSION['b'] ?></b></p>
               </div></div>

               <div class="col-md-4">
                  <br>
              <center><input type="submit" class="btn" name="submit" value="Add"></center>
               </div>
            </div>
        </div>
      </div>


            <div class="col-md-4">
        <div class="card">
          <img src="asserts/images/img3.jpg" width="100%" height="200">
             <div class="row" style="margin-top: 10px;">
          <div class="col-md-6">
               <p style="color:#8e44ad;"><b>&nbsp;&nbsp;<?php echo $_SESSION['C'] ?></b></p> </div>
              <div class="col-md-6">
                 <div class="quantity buttons_added" style="float: right;">
  <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity_1" value="1" title="Qty" class="input-text qty text form-control" size="4" pattern="" inputmode=""><input type="button" value="+" class="plus">
            </div></div></div>

            <div class="row">
               <div class="col-md-8">
                <div style="margin-top:-10px">
                &nbsp;&nbsp;<i class="glyphicon glyphicon-star" style="color: #e39738">5</i><p><br></p>
                <p><b>&nbsp;&nbsp;₹<?php echo $_SESSION['c'] ?></b></p>
               </div></div>

               <div class="col-md-4">
                  <br>
              <center><input type="submit" class="btn" name="submit" value="Add"></center>
               </div>
            </div>
        </div>
      </div>
    </div> 
  </div>
</div> 




  <div class="container-fluid">
  <div class="col-md-12">
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <img src="asserts/images/img1.jpg" width="100%" height="200">
             <div class="row" style="margin-top: 10px;">
          <div class="col-md-6">
               <p style="color:#8e44ad;"><b>&nbsp;&nbsp;<?php echo $_SESSION['D'] ?></b></p> </div>
              <div class="col-md-6">
                 <div class="quantity buttons_added" style="float: right;">
  <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity_1" value="1" title="Qty" class="input-text qty text form-control" size="4" pattern="" inputmode=""><input type="button" value="+" class="plus">
            </div></div></div>

            <div class="row">
               <div class="col-md-8">
                <div style="margin-top:-10px">
                &nbsp;&nbsp;<i class="glyphicon glyphicon-star" style="color: #e39738">5</i><p><br></p>
                <p><b>&nbsp;&nbsp;₹<?php echo $_SESSION['d'] ?></b></p>
               </div></div>

               <div class="col-md-4">
                  <br>
              <center><input type="submit" class="btn" name="submit" value="Add"></center>
               </div>
            </div>
        </div>
      </div>

            <div class="col-md-4">
        <div class="card">
          <img src="asserts/images/img2.jpg" width="100%" height="200">
             <div class="row" style="margin-top: 10px;">
          <div class="col-md-6">
               <p style="color:#8e44ad;"><b>&nbsp;&nbsp;<?php echo $_SESSION['E'] ?></b></p> </div>
              <div class="col-md-6">
                 <div class="quantity buttons_added" style="float: right;">
  <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity_1" value="1" title="Qty" class="input-text qty text form-control" size="4" pattern="" inputmode=""><input type="button" value="+" class="plus">
            </div></div></div>

            <div class="row">
               <div class="col-md-8">
                <div style="margin-top:-10px">
                &nbsp;&nbsp;<i class="glyphicon glyphicon-star" style="color: #e39738">5</i><p><br></p>
                <p><b>&nbsp;&nbsp;₹<?php echo $_SESSION['e'] ?></b></p>
               </div></div>

               <div class="col-md-4">
                  <br>
              <center><input type="submit" class="btn" name="submit" value="Add"></center>
               </div>
            </div>
        </div>
      </div>


            <div class="col-md-4">
        <div class="card">
          <img src="asserts/images/img3.jpg" width="100%" height="200">
             <div class="row" style="margin-top: 10px;">
          <div class="col-md-6">
               <p style="color:#8e44ad;"><b>&nbsp;&nbsp;<?php echo $_SESSION['F'] ?></b></p> </div>
              <div class="col-md-6">
                 <div class="quantity buttons_added" style="float: right;">
  <input type="button" value="-" class="minus"><input type="number" step="1" min="1" max="" name="quantity_1" value="1" title="Qty" class="input-text qty text form-control" size="4" pattern="" inputmode=""><input type="button" value="+" class="plus">
            </div></div></div>

            <div class="row">
               <div class="col-md-8">
                <div style="margin-top:-10px">
                &nbsp;&nbsp;<i class="glyphicon glyphicon-star" style="color: #e39738">5</i><p><br></p>
                <p><b>&nbsp;&nbsp;₹<?php echo $_SESSION['f'] ?></b></p>
               </div></div>

               <div class="col-md-4">
                  <br>
              <center><input type="submit" class="btn" name="submit" value="Add"></center>
               </div>
            </div>
        </div>
      </div>
    </div> 
  </div>
</div> 

 
<br><br>
             <div class="footer">
                         <div class="row"style="color:#f5f6fa ;background:#101010;">
                              <div class="col-md-3 text-center">
                                  <h4><span class="glyphicon glyphicon-map-marker"></span>&nbsp;Location</h4>
                                  A17 & 18,guindy industrial estate<br>
                                  sidco industrial estate,guindy<br>
                                  chennai,tamil nadu 600032
                              </div>
                              <div class="col-md-3 text-center">
                                  <h4><span class="glyphicon glyphicon-earphone"></span>&nbsp;Contact</h4>
                                  044 4204 0045
                                
                              </div>
                              <div class="col-md-3 text-center">
                                   <h4><span class="glyphicon glyphicon-envelope"></span>&nbsp;Email</h4>
                                   sales@perficient.com
                              </div>
                              <div class="col-md-3 text-center">
                                   <h4><span class="glyphicon glyphicon-paperclip"></span>&nbsp;Website</h4>
                                   https://www.perficient.com
                              </div>
               </div>
                   

        
     </div>

  
    
        <!--<a href="reset.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>-->
    </p>
</body>
</html>