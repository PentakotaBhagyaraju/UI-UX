<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: web.php");
    exit;
}
 
// Include config file
require_once "database.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bind_param("s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Store result
                $stmt->store_result();
                
                // Check if username exists, if yes then verify password
                if($stmt->num_rows == 1){                    
                    // Bind result variables
                    $stmt->bind_result($id, $username, $hashed_password);
                    if($stmt->fetch()){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: web.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            $stmt->close();
        }
    }
    
    // Close connection
    $mysqli->close();
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
   <title>Sign-in</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
         body{
    background-image: url('asserts/images/log bg.png');
    background-size: cover;
  }

        .card{
    border: 2px solid #8e44ad;
    box-shadow: 10px 10px 10px #eee;
    height: 400px;
    border-radius:20px;
    opacity: 1;
     background-image: url('asserts/images/log bg.png');
  }
        .container-fluid{
        
            height: 568px;
            width: 100%;
            background-position: center;
  background-repeat: no-repeat;
  background-size: cover;


        }
      .btn{
    border: 1px solid #8e44ad;
    border-radius: 17px;
    
   
  }
    </style>
</head>
<body>
        <div class="container-fluid">
    <div class="container" style="margin-top:100px">
    <div class="row">
        <div class="col-md-4"></div>
       <div class="col-md-4">
         <div class="card">
            <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <center><h1 style="font-family: none;">Sign-in</h1></center>
            <div class="row">
            
                
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="form-group">
            <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>"placeholder="User Name" style="border-radius:15px;padding: 10px; required><span class="invalid-feedback"><?php echo $username_err; ?></span></div>
            <div><br>
            <input type="Password" name="password" class="form-control <?php echo (!empty($password_err))? 'is-invalid' : ''; ?>" placeholder="Password" style="border-radius:15px;padding: 10px;"required><span class="invalid-feedback"><?php echo $password_err; ?></span>
</div><br>
    <div>
                        
            <center> <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Login">
            </div>
            </center>
             <p style="color:whitesmoke">Don't have an account? <center><a style="color:#e517cc" 
                href="sign-up.php"><b>Sign up now<b></a>.</center></p>
            <center><a href="#"><img src="asserts/images/fb.jpg" width="25px" height="25px"></img></a>&nbsp;&nbsp;
            <a href="#"><img src="asserts/images/gmail.jpg" width="25px" height="25px"></img></a>&nbsp;&nbsp;
    <a href="#"><img src="asserts/images/insta.jpg" width="25px" height="25px"></img></a></center></form>
        
        <div class="col-md-3"></div>
</div>
           <div class="col-md-4"></div>
         </div>
         
      </div></div>
</body>
</html>