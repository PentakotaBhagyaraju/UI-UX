
<?php
// Initialize the session

session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: log-in.php");
    exit;
}


?>
<!DOCTYPE html>
<html>
<head>
  <title>Food Cartx</title>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
  background-image: url("asserts/images/background.png");
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}


.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}



.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}


</style>
</head>
<body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#" style="margin-left: 10px;">Custom<br>Cuisine</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" style="margin-left: 10px;">
        <li class="active"><a href="web.php">Home</a></li>

        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="addcart.php"><button type="button" class="btn btn-default btn-sm" style="margin-top: -5px;">
          <span class="glyphicon glyphicon-shopping-cart"></span> Food Cart
        </button></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> <?php echo htmlspecialchars($_SESSION["username"]); ?>
        </a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Log-out</a></li>
      </ul>
    </div>
  </div>
</nav>


    <div class="container">
      <div class="row"><div class="col-md-3"></div>
      <div class="col-md-6">
            <h4>Cart <span class="price" style="color:black"><i class="fa fa-shopping-cart"></i></span></h4>
  <p><?php echo $_SESSION['A'] ?> <span class="price">₹<?php echo $_SESSION['a']; ?></span></p>
    

      <hr>
      <h4><b>suggestion Box:</b></h4>
      <textarea type="text" value=""></textarea>
       
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="raj">
            <label for="ccnum">Credit card number</label>
            <input type="number" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September">
            <div class="row">
              <div class="col-md-6">
                <label for="expyear">Exp Year</label>
                <input type="number" id="expyear" name="expyear" placeholder="2018">
              </div>
              <div class="col-md-6">
                <label for="cvv">CVV</label>
                <input type="number" id="cvv" name="cvv" placeholder="352">
              </div>
            </div>
          
      <br>
        
      <a href="web.php"><input type="submit" onclick="alert('Your Order Placed Successfully')" style="border: 1px solid #8e44ad;
    color: black;" class="btn"></input></a>
    
</div>

</div>
</div><br>
 <div class="footer">
                         <div class="row"style="color:#f5f6fa ;background:#101010;">
                              <div class="col-md-3 text-center">
                                  <h4><span class="glyphicon glyphicon-map-marker"></span>&nbsp;Location</h4>
                                  A17 & 18,guindy industrial estate<br>
                                  sidco industrial estate,guindy<br>
                                  chennai,tamil nadu 600032
                              </div>
                              <div class="col-md-3 text-center">
                                  <h4><span class="glyphicon glyphicon-earphone"></span>&nbsp;Contact</h4>
                                  044 4204 0045
                                
                              </div>
                              <div class="col-md-3 text-center">
                                   <h4><span class="glyphicon glyphicon-envelope"></span>&nbsp;Email</h4>
                                   sales@perficient.com
                              </div>
                              <div class="col-md-3 text-center">
                                   <h4><span class="glyphicon glyphicon-paperclip"></span>&nbsp;Website</h4>
                                   https://www.perficient.com
                              </div>
               </div>
                   

        
     </div>

</body>
</html>
